package com.example.screenmathsolver;

import android.app.*;
import android.content.pm.ServiceInfo;
import android.content.*;
import android.graphics.*;
import android.hardware.display.*;
import android.media.*;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import java.nio.ByteBuffer;
import android.os.*;
import android.view.*;
import android.widget.*;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.util.concurrent.Executors;

public class OverlayCaptureService extends Service {
    private WindowManager wm; private View bubble; private TextView result; private MediaProjection mp; private ImageReader reader; private VirtualDisplay vd; private Handler h; private boolean scanning=false; private long lastMs=0;
    private final android.os.HandlerThread worker = new android.os.HandlerThread("ocr");

    @Override public void onCreate(){ super.onCreate(); worker.start(); h=new Handler(worker.getLooper()); createNotification(); }
    private void createNotification(){ String ch="solver"; NotificationManager nm=getSystemService(NotificationManager.class); if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(new NotificationChannel(ch,"Screen solver",NotificationManager.IMPORTANCE_LOW)); Notification n=new Notification.Builder(this,ch).setContentTitle("Screen Math Solver").setContentText("Floating OCR solver running").setSmallIcon(android.R.drawable.ic_menu_view).build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(7, n);
        } }

    @Override public int onStartCommand(Intent i,int flags,int id){
        int resultCode=i.getIntExtra("resultCode",Activity.RESULT_CANCELED); Intent data=i.getParcelableExtra("data");
        if(data==null) return START_NOT_STICKY;
        mp=((MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE)).getMediaProjection(resultCode,data);
        showBubble(); startCapture(); return START_STICKY;
    }

    private void showBubble(){
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(14,10,14,10); box.setBackgroundColor(Color.argb(235,12,20,35));
        TextView title=new TextView(this); title.setText("⚡ Screen Solver"); title.setTextColor(Color.WHITE); title.setTextSize(16); title.setTypeface(null,1);
        result=new TextView(this); result.setText("Tap SCAN"); result.setTextColor(Color.rgb(124,255,155)); result.setTextSize(18); result.setPadding(0,8,0,8);
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        Button scan=new Button(this); scan.setText("SCAN"); scan.setOnClickListener(v->captureOnce());
        Button auto=new Button(this); auto.setText("AUTO"); auto.setOnClickListener(v->{scanning=!scanning; auto.setText(scanning?"STOP":"AUTO"); if(scanning) loop();});
        Button close=new Button(this); close.setText("X"); close.setOnClickListener(v->stopSelf());
        row.addView(scan); row.addView(auto); row.addView(close);
        box.addView(title); box.addView(result); box.addView(row);
        bubble=box;
        WindowManager.LayoutParams lp=new WindowManager.LayoutParams(WRAP_CONTENT,WRAP_CONTENT,Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,PixelFormat.TRANSLUCENT);
        lp.gravity=Gravity.TOP|Gravity.END; lp.x=12; lp.y=130; wm.addView(bubble,lp);
        final int[] down={0,0,0,0}; box.setOnTouchListener((v,e)->{ if(e.getAction()==MotionEvent.ACTION_DOWN){down[0]=(int)e.getRawX();down[1]=(int)e.getRawY();WindowManager.LayoutParams p=(WindowManager.LayoutParams)bubble.getLayoutParams();down[2]=p.x;down[3]=p.y;return true;} if(e.getAction()==MotionEvent.ACTION_MOVE){WindowManager.LayoutParams p=(WindowManager.LayoutParams)bubble.getLayoutParams(); p.x=down[2]-(int)e.getRawX()+down[0]; p.y=down[3]+(int)e.getRawY()-down[1]; wm.updateViewLayout(bubble,p);return true;} return false;});
    }

    private void startCapture(){
        DisplayMetrics d=getResources().getDisplayMetrics(); reader=ImageReader.newInstance(d.widthPixels,d.heightPixels,PixelFormat.RGBA_8888,2); vd=mp.createVirtualDisplay("solver",d.widthPixels,d.heightPixels,d.densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,h); }
    private void loop(){ h.postDelayed(()->{ if(scanning){captureOnce(); loop();}},1500); }
    private void captureOnce(){ if(reader==null)return; Image im=reader.acquireLatestImage(); if(im==null)return; Bitmap b=imageToBitmap(im); im.close(); if(b==null)return; InputImage ii=InputImage.fromBitmap(b,0); TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(ii).addOnSuccessListener(r->{String t=r.getText(); String a=MathSolver.solveText(t); runOnMain(()->result.setText(a));}).addOnFailureListener(e->runOnMain(()->result.setText("OCR failed"))); }
    private Bitmap imageToBitmap(Image image){ Image.Plane p=image.getPlanes()[0]; ByteBuffer bb=p.getBuffer(); int ps=p.getPixelStride(), rs=p.getRowStride(), pad=rs-ps*image.getWidth(); Bitmap bm=Bitmap.createBitmap(image.getWidth()+pad/ps,image.getHeight(),Bitmap.Config.ARGB_8888); bm.copyPixelsFromBuffer(bb); return Bitmap.createBitmap(bm,0,0,image.getWidth(),image.getHeight()); }
    private void runOnMain(Runnable r){ new Handler(Looper.getMainLooper()).post(r); }
    @Override public void onDestroy(){ scanning=false; try{if(bubble!=null&&wm!=null)wm.removeView(bubble);}catch(Exception ignored){} try{if(vd!=null)vd.release(); if(reader!=null)reader.close(); if(mp!=null)mp.stop();}catch(Exception ignored){} worker.quitSafely(); super.onDestroy(); }
    @Override public IBinder onBind(Intent i){return null;}
}
