package com.example.screenmathsolver;

import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.os.Build;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int REQ_CAPTURE = 1001;
    private TextView status;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 3001);
        setContentView(R.layout.activity_main);
        status = findViewById(R.id.status);
        Button btn = findViewById(R.id.overlayBtn);
        btn.setOnClickListener(v -> startOverlay());
    }

    private void startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            status.setText("Allow 'Display over other apps', then return here.");
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(i);
            return;
        }
        MediaProjectionManager mpm = (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_CAPTURE && resultCode == RESULT_OK && data != null) {
            Intent svc = new Intent(this, OverlayCaptureService.class);
            svc.putExtra("resultCode", resultCode);
            svc.putExtra("data", data);
            startForegroundService(svc);
            status.setText("Floating scanner is running. Tap SCAN in the bubble.");
        } else {
            status.setText("Screen capture permission was cancelled.");
        }
    }
}
