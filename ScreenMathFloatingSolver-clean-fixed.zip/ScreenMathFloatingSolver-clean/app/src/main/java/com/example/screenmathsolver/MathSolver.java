package com.example.screenmathsolver;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MathSolver {
    private static final DecimalFormat DF = new DecimalFormat("0.##########");

    public static String solveText(String raw) {
        if (raw == null) return "No supported math found";
        String text = raw
                .replace("×", "*")
                .replace("÷", "/")
                .replace("−", "-")
                .replace("–", "-")
                .replace("²", "^2")
                .replace("³", "^3");

        ArrayList<String> out = new ArrayList<>();

        Matcher pm = Pattern.compile(
                "(?i)([-+]?\\d+(?:\\.\\d+)?)\\s*%\\s*(?:of|\\*)\\s*([-+]?\\d+(?:\\.\\d+)?)"
        ).matcher(text);
        while (pm.find()) {
            double a = Double.parseDouble(pm.group(1));
            double b = Double.parseDouble(pm.group(2));
            out.add(pm.group(0) + " = " + DF.format(a * b / 100.0));
        }

        String compact = text.replaceAll("\\s+", "");
        Matcher qm = Pattern.compile(
                "(?i)([-+]?\\d*\\.?\\d*)\\^?2([+-]\\d*\\.?\\d*)x([+-]\\d+(?:\\.\\d+)?)=0"
        ).matcher(compact);
        while (qm.find()) {
            double a = parseCoeff(qm.group(1), 1);
            double b = parseCoeff(qm.group(2), 0);
            double c = Double.parseDouble(qm.group(3));
            double d = b * b - 4 * a * c;
            if (Math.abs(a) < 1e-12) {
                out.add("Invalid quadratic");
            } else if (d < 0) {
                out.add(qm.group(0) + " -> no real roots");
            } else {
                double r1 = (-b + Math.sqrt(d)) / (2 * a);
                double r2 = (-b - Math.sqrt(d)) / (2 * a);
                String roots = "x=" + DF.format(r1);
                if (Math.abs(r1 - r2) > 1e-10) roots += ", " + DF.format(r2);
                out.add(qm.group(0) + " -> " + roots);
            }
        }

        Matcher lm = Pattern.compile(
                "(?i)^([+-]?\\d*\\.?\\d*)x([+-]\\d+(?:\\.\\d+)?)=([+-]?\\d+(?:\\.\\d+)?)$"
        ).matcher(compact);
        if (lm.find()) {
            double a = parseCoeff(lm.group(1), 1);
            double b = Double.parseDouble(lm.group(2));
            double c = Double.parseDouble(lm.group(3));
            if (Math.abs(a) < 1e-12) {
                out.add("Invalid linear equation");
            } else {
                out.add("x = " + DF.format((c - b) / a));
            }
        }

        String expr = compact;
        if (expr.matches("[0-9.()+\\-*/%^]+")) {
            try {
                out.add(expr + " = " + DF.format(eval(expr)));
            } catch (Exception ignored) {
                // Not a valid arithmetic expression.
            }
        }

        if (out.isEmpty()) return "No supported math found";
        return String.join("\n", out);
    }

    private static double parseCoeff(String s, double defaultVal) {
        if (s == null || s.isEmpty() || s.equals("+")) return defaultVal;
        if (s.equals("-")) return -defaultVal;
        return Double.parseDouble(s);
    }

    private static double eval(String s) {
        return new Parser(s).parse();
    }

    private static final class Parser {
        private final String s;
        private int p = 0;

        Parser(String s) { this.s = s; }

        double parse() {
            double v = expr();
            if (p != s.length()) throw new IllegalArgumentException();
            return v;
        }

        double expr() {
            double v = term();
            while (p < s.length()) {
                char c = s.charAt(p);
                if (c != '+' && c != '-') break;
                p++;
                double r = term();
                v = c == '+' ? v + r : v - r;
            }
            return v;
        }

        double term() {
            double v = pow();
            while (p < s.length()) {
                char c = s.charAt(p);
                if (c != '*' && c != '/' && c != '%') break;
                p++;
                double r = pow();
                if (c == '*') v *= r;
                else if (c == '/') v /= r;
                else v %= r;
            }
            return v;
        }

        double pow() {
            double v = unary();
            if (p < s.length() && s.charAt(p) == '^') {
                p++;
                v = Math.pow(v, pow());
            }
            return v;
        }

        double unary() {
            if (p < s.length()) {
                char c = s.charAt(p);
                if (c == '+' || c == '-') {
                    p++;
                    return c == '-' ? -unary() : unary();
                }
            }
            if (p < s.length() && s.charAt(p) == '(') {
                p++;
                double v = expr();
                if (p >= s.length() || s.charAt(p) != ')') throw new IllegalArgumentException();
                p++;
                return v;
            }
            int st = p;
            while (p < s.length() && (Character.isDigit(s.charAt(p)) || s.charAt(p) == '.')) p++;
            if (st == p) throw new IllegalArgumentException();
            return Double.parseDouble(s.substring(st, p));
        }
    }
}
