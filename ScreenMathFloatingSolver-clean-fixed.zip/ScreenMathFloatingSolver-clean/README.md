# Screen Math Floating Solver

Android study/practice utility that asks for screen-capture permission, OCRs the current screen with ML Kit, and shows detected basic-math answers in a draggable floating overlay.

## Build on a phone
The project includes `.github/workflows/build.yml`, so the easiest reliable phone-only route is to push the complete folder tree to GitHub using Git from Termux. The GitHub Actions workflow then builds a debug APK automatically.

See `UPLOAD_FROM_PHONE.txt` for the exact phone steps.

## Android project structure
- `app/` is the Android application module.
- `.github/workflows/build.yml` is the GitHub Actions build workflow.
- `MainActivity.java`, `MathSolver.java`, and `OverlayCaptureService.java` belong inside the `app/src/main/java/...` package directory.

## Run
Open the app, allow **Display over other apps**, then approve Android's **screen capture** prompt. A draggable floating solver appears. Use **SCAN** for one OCR pass or **AUTO** for periodic scanning.

Use only on content you are permitted to analyze and for study/practice.
