package com.example.screenmathsolver;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class MathSolver {
    private static final DecimalFormat DF = new DecimalFormat("0.##########");
    private MathSolver() {}

    public static String solveText(String raw) {
        if (raw == null || raw.trim().isEmpty()) return "No supported math found";

        String normalized = normalize(raw);
        ArrayList<String> answers = new ArrayList<>();

        String[] lines = normalized.split("[\\r\\n]+");
        for (String originalLine : lines) {
            String line = originalLine.trim();
            if (line.isEmpty()) continue;

            // Percentage: 15% of 240 OR 15% * 240
            Matcher pct = Pattern.compile("(?i)^([-+]?\\d+(?:\\.\\d+)?)%\\s*(?:of|\\*)\\s*([-+]?\\d+(?:\\.\\d+)?)$").matcher(line);
            if (pct.matches()) {
                double a = Double.parseDouble(pct.group(1));
                double b = Double.parseDouble(pct.group(2));
                answers.add(line + " = " + DF.format(a * b / 100.0));
                continue;
            }

            String compact = line.replaceAll("\\s+", "");

            Matcher quad = Pattern.compile("(?i)^([-+]?\\d*\\.?\\d*)x\\^2([+-]\\d*\\.?\\d*)x([+-]\\d+(?:\\.\\d+)?)=0$").matcher(compact);
            if (quad.matches()) {
                double a = parseCoeff(quad.group(1), 1);
                double b = parseCoeff(quad.group(2), 0);
                double c = Double.parseDouble(quad.group(3));
                if (Math.abs(a) < 1e-12) {
                    answers.add("Invalid quadratic");
                } else {
                    double d = b * b - 4.0 * a * c;
                    if (d < -1e-12) {
                        answers.add(compact + " -> no real roots");
                    } else {
                        double rootD = Math.sqrt(Math.max(0.0, d));
                        double r1 = (-b + rootD) / (2.0 * a);
                        double r2 = (-b - rootD) / (2.0 * a);
                        String answer = "x = " + DF.format(r1);
                        if (Math.abs(r1 - r2) > 1e-10) answer += ", " + DF.format(r2);
                        answers.add(compact + " -> " + answer);
                    }
                }
                continue;
            }

            Matcher linear = Pattern.compile("(?i)^([+-]?\\d*\\.?\\d*)x([+-]\\d+(?:\\.\\d+)?)=([+-]?\\d+(?:\\.\\d+)?)$").matcher(compact);
            if (linear.matches()) {
                double a = parseCoeff(linear.group(1), 1);
                double b = Double.parseDouble(linear.group(2));
                double c = Double.parseDouble(linear.group(3));
                if (Math.abs(a) < 1e-12) {
                    answers.add("Invalid linear equation");
                } else {
                    answers.add("x = " + DF.format((c - b) / a));
                }
                continue;
            }

            if (compact.matches("[0-9.()+\\-*/%^]+")) {
                try {
                    answers.add(compact + " = " + DF.format(new Parser(compact).parse()));
                } catch (RuntimeException ignored) {
                    // Not a supported arithmetic expression.
                }
            }
        }

        return answers.isEmpty() ? "No supported math found" : String.join("\n", answers);
    }

    private static String normalize(String value) {
        return value
                .replace('×', '*')
                .replace('÷', '/')
                .replace('−', '-')
                .replace('–', '-')
                .replace('—', '-')
                .replace("²", "^2")
                .replace("³", "^3")
                .replace(',', ' ');
    }

    private static double parseCoeff(String s, double defaultValue) {
        if (s == null || s.isEmpty() || s.equals("+")) return defaultValue;
        if (s.equals("-")) return -defaultValue;
        return Double.parseDouble(s);
    }

    private static final class Parser {
        private final String s;
        private int p;

        Parser(String s) { this.s = s; }

        double parse() {
            double value = expression();
            if (p != s.length()) throw new IllegalArgumentException("Unexpected input");
            return value;
        }

        private double expression() {
            double value = term();
            while (p < s.length()) {
                char op = s.charAt(p);
                if (op != '+' && op != '-') break;
                p++;
                double rhs = term();
                value = op == '+' ? value + rhs : value - rhs;
            }
            return value;
        }

        private double term() {
            double value = power();
            while (p < s.length()) {
                char op = s.charAt(p);
                if (op != '*' && op != '/' && op != '%') break;
                p++;
                double rhs = power();
                if (op == '*') value *= rhs;
                else if (op == '/') value /= rhs;
                else value %= rhs;
            }
            return value;
        }

        private double power() {
            double value = unary();
            if (p < s.length() && s.charAt(p) == '^') {
                p++;
                value = Math.pow(value, power());
            }
            return value;
        }

        private double unary() {
            if (p < s.length()) {
                char op = s.charAt(p);
                if (op == '+' || op == '-') {
                    p++;
                    double value = unary();
                    return op == '-' ? -value : value;
                }
            }

            if (p < s.length() && s.charAt(p) == '(') {
                p++;
                double value = expression();
                if (p >= s.length() || s.charAt(p) != ')') throw new IllegalArgumentException("Missing )");
                p++;
                return value;
            }

            int start = p;
            while (p < s.length()) {
                char c = s.charAt(p);
                if (!Character.isDigit(c) && c != '.') break;
                p++;
            }
            if (start == p) throw new IllegalArgumentException("Number expected");
            return Double.parseDouble(s.substring(start, p));
        }
    }
}
