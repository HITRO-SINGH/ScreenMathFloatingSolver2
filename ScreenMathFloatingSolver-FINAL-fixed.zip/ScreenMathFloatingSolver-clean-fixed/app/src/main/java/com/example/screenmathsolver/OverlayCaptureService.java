package com.example.screenmathsolver;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.nio.ByteBuffer;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

public class OverlayCaptureService extends Service {
    private static final String CHANNEL_ID = "screen_solver";
    private static final int NOTIFICATION_ID = 7;

    private WindowManager windowManager;
    private View overlayView;
    private TextView resultView;
    private MediaProjection mediaProjection;
    private ImageReader imageReader;
    private VirtualDisplay virtualDisplay;
    private TextRecognizer recognizer;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private ScheduledExecutorService scheduler;
    private final AtomicBoolean scanning = new AtomicBoolean(false);

    private final Runnable scanRunnable = new Runnable() {
        @Override public void run() {
            if (scanning.get()) {
                captureAndRecognize();
                mainHandler.postDelayed(this, 1500L);
            }
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        scheduler = Executors.newSingleThreadScheduledExecutor();
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        createNotificationChannel();
        startForegroundNotification();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(new NotificationChannel(
                    CHANNEL_ID, "Screen Math Solver", NotificationManager.IMPORTANCE_LOW));
        }
    }

    private void startForegroundNotification() {
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        Notification notification = builder
                .setContentTitle("Screen Math Solver")
                .setContentText("Floating OCR solver is running")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setOngoing(true)
                .build();

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification,
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;

        int resultCode = intent.getIntExtra("resultCode", Activity.RESULT_CANCELED);
        Intent data;
        if (Build.VERSION.SDK_INT >= 33) {
            data = intent.getParcelableExtra("data", Intent.class);
        } else {
            data = intent.getParcelableExtra("data");
        }
        if (resultCode != Activity.RESULT_OK || data == null) {
            stopSelf();
            return START_NOT_STICKY;
        }

        if (mediaProjection == null) {
            MediaProjectionManager manager =
                    (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            mediaProjection = manager.getMediaProjection(resultCode, data);
            if (mediaProjection == null) {
                stopSelf();
                return START_NOT_STICKY;
            }
            mediaProjection.registerCallback(new MediaProjection.Callback() {
                @Override public void onStop() { stopSelf(); }
            }, mainHandler);
        }

        showOverlay();
        startCapture();
        return START_NOT_STICKY;
    }

    private void showOverlay() {
        if (overlayView != null) return;
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(14, 10, 14, 10);
        box.setBackgroundColor(Color.argb(238, 12, 20, 35));

        TextView title = new TextView(this);
        title.setText("Screen Solver");
        title.setTextColor(Color.WHITE);
        title.setTextSize(16);
        title.setTypeface(null, 1);

        resultView = new TextView(this);
        resultView.setText("Tap SCAN");
        resultView.setTextColor(Color.rgb(124, 255, 155));
        resultView.setTextSize(18);
        resultView.setPadding(0, 8, 0, 8);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);

        Button scan = new Button(this);
        scan.setText("SCAN");
        scan.setOnClickListener(v -> captureAndRecognize());

        Button auto = new Button(this);
        auto.setText("AUTO");
        auto.setOnClickListener(v -> {
            boolean now = !scanning.get();
            scanning.set(now);
            auto.setText(now ? "STOP" : "AUTO");
            if (now) mainHandler.post(scanRunnable);
            else mainHandler.removeCallbacks(scanRunnable);
        });

        Button close = new Button(this);
        close.setText("X");
        close.setOnClickListener(v -> stopSelf());

        row.addView(scan, weightParams());
        row.addView(auto, weightParams());
        row.addView(close, weightParams());

        box.addView(title);
        box.addView(resultView);
        box.addView(row);
        overlayView = box;

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.END;
        lp.x = 12;
        lp.y = 120;
        windowManager.addView(overlayView, lp);

        final float[] down = new float[2];
        final int[] startPos = new int[2];
        box.setOnTouchListener((view, event) -> {
            WindowManager.LayoutParams current = (WindowManager.LayoutParams) overlayView.getLayoutParams();
            if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
                down[0] = event.getRawX();
                down[1] = event.getRawY();
                startPos[0] = current.x;
                startPos[1] = current.y;
            } else if (event.getActionMasked() == MotionEvent.ACTION_MOVE) {
                current.x = startPos[0] - Math.round(event.getRawX() - down[0]);
                current.y = startPos[1] + Math.round(event.getRawY() - down[1]);
                windowManager.updateViewLayout(overlayView, current);
                return true;
            }
            return false;
        });
    }

    private LinearLayout.LayoutParams weightParams() {
        return new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
    }

    private void startCapture() {
        if (virtualDisplay != null || mediaProjection == null) return;

        DisplayMetrics metrics = getResources().getDisplayMetrics();
        int width = metrics.widthPixels;
        int height = metrics.heightPixels;
        int density = metrics.densityDpi;

        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2);
        virtualDisplay = mediaProjection.createVirtualDisplay(
                "ScreenMathFloatingSolver", width, height, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.getSurface(), null, mainHandler);
    }

    private void captureAndRecognize() {
        if (imageReader == null || recognizer == null) return;

        Image image = imageReader.acquireLatestImage();
        if (image == null) {
            postResult("Waiting for screen frame...");
            return;
        }

        Bitmap bitmap = null;
        try {
            bitmap = imageToBitmap(image);
        } finally {
            image.close();
        }
        if (bitmap == null) {
            postResult("Capture failed");
            return;
        }

        InputImage input = InputImage.fromBitmap(bitmap, 0);
        recognizer.process(input)
                .addOnSuccessListener(result -> postResult(MathSolver.solveText(result.getText())))
                .addOnFailureListener(error -> postResult("OCR failed"));
    }

    private Bitmap imageToBitmap(Image image) {
        Image.Plane plane = image.getPlanes()[0];
        ByteBuffer buffer = plane.getBuffer();
        int pixelStride = plane.getPixelStride();
        int rowStride = plane.getRowStride();
        int rowPadding = rowStride - pixelStride * image.getWidth();
        int paddedWidth = image.getWidth() + rowPadding / pixelStride;

        Bitmap bitmap = Bitmap.createBitmap(paddedWidth, image.getHeight(), Bitmap.Config.ARGB_8888);
        buffer.rewind();
        bitmap.copyPixelsFromBuffer(buffer);
        return Bitmap.createBitmap(bitmap, 0, 0, image.getWidth(), image.getHeight());
    }

    private void postResult(String text) {
        mainHandler.post(() -> {
            if (resultView != null) resultView.setText(text);
        });
    }

    @Override
    public void onDestroy() {
        scanning.set(false);
        mainHandler.removeCallbacks(scanRunnable);
        if (scheduler != null) {
            scheduler.shutdownNow();
            scheduler = null;
        }
        if (overlayView != null && windowManager != null) {
            try { windowManager.removeView(overlayView); } catch (Exception ignored) {}
            overlayView = null;
        }
        if (virtualDisplay != null) {
            try { virtualDisplay.release(); } catch (Exception ignored) {}
            virtualDisplay = null;
        }
        if (imageReader != null) {
            try { imageReader.close(); } catch (Exception ignored) {}
            imageReader = null;
        }
        if (mediaProjection != null) {
            try { mediaProjection.stop(); } catch (Exception ignored) {}
            mediaProjection = null;
        }
        if (recognizer != null) {
            try { recognizer.close(); } catch (Exception ignored) {}
            recognizer = null;
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
