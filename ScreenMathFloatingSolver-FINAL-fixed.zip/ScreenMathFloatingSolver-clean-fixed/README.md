# Screen Math Floating Solver
Android study/practice utility with screen capture, ML Kit OCR, and a draggable floating overlay.
