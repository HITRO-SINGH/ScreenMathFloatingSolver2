# Screen Math Floating Solver

Android study/practice utility that uses Android screen capture, ML Kit OCR, and a draggable floating overlay to show supported basic-math answers.

## Supported examples
- `25 + 37`
- `144 / 12`
- `15% of 240`
- `2x + 7 = 19`
- `x^2 - 5x + 6 = 0`

## Phone-only build
1. Upload this ZIP to the root of a GitHub repository.
2. Create `.github/workflows/build.yml` using the workflow supplied separately.
3. The workflow installs Java 17, Android SDK 35, Gradle 8.7, builds `assembleDebug`, and uploads `app-debug.apk` as an artifact.

## First launch
1. Allow **Display over other apps**.
2. Approve Android's **screen capture** prompt.
3. A draggable floating overlay appears.
4. Use `SCAN` for one pass or `AUTO` for periodic scans.

The app does not click or type into other apps automatically.
